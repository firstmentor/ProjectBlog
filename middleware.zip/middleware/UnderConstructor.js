var UnderConstructor=(req,res,next)=>{
res.render("demo")
next()
}

module.exports=UnderConstructor;